package com.unicolombo.ColomboPedia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColomboPediaApplicationTests {

	@Test
	void contextLoads() {
	}

}
