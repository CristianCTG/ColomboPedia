package com.unicolombo.ColomboPedia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ColomboPediaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ColomboPediaApplication.class, args);
	}

}
